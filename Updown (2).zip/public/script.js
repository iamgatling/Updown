const uploadForm = document.getElementById('uploadForm');
const fileInput = document.getElementById('fileInput');
const message = document.getElementById('message');
const fileList = document.getElementById('fileList');

uploadForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const formData = new FormData();
  formData.append('file', fileInput.files[0]);

  try {
    const response = await fetch('/upload', {
      method: 'POST',
      body: formData,
    });
    const data = await response.json();
    message.textContent = data.success;
    fileInput.value = ''; // Clear the file input field
    fetchFileList(); // Refresh the file list
  } catch (error) {
    console.error('Error uploading file:', error);
    message.textContent = 'Error uploading file';
  }
});

async function fetchFileList() {
  try {
    const response = await fetch('/list');
    const files = await response.json();
    renderFileList(files);
  } catch (error) {
    console.error('Error fetching file list:', error);
  }
}

function renderFileList(files) {
  fileList.innerHTML = '';
  files.forEach(file => {
    const link = document.createElement('a');
    link.href = `/download/${file}`;
    link.textContent = file;
    link.setAttribute('target', '_blank');
    fileList.appendChild(link);
    fileList.appendChild(document.createElement('br'));
  });
}

// Fetch initial file list when the page loads
fetchFileList();

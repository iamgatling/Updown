const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// Set storage engine
const storage = multer.diskStorage({
  destination: './uploads/',
  filename: function(req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
  }
});

// Init upload
const upload = multer({
  storage: storage,
  limits: { fileSize: 1000000 }, // 1MB file size limit
}).single('file');

// Static folder
app.use(express.static('./public'));

// Upload route
app.post('/upload', (req, res) => {
  upload(req, res, (err) => {
    if (err) {
      res.send({ error: err });
    } else {
      if (req.file == undefined) {
        res.send({ error: 'No file selected' });
      } else {
        res.send({ success: 'File uploaded successfully' });
      }
    }
  });
});

// Download route
app.get('/download/:filename', (req, res) => {
  const fileName = req.params.filename;
  const filePath = path.join(__dirname, '/uploads/', fileName);
  res.download(filePath);
});

// List route
app.get('/list', (req, res) => {
  fs.readdir('./uploads', (err, files) => {
    if (err) {
      console.error('Error reading directory:', err);
      res.status(500).json({ error: 'Error reading directory' });
    } else {
      res.json(files);
    }
  });
});

app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
